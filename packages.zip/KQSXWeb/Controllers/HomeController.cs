﻿using KQSXWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Syndication;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Xml;

namespace KQSXWeb.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            string rssUrl = "https://xskt.com.vn/rss-feed/mien-bac-xsmb.rss";

            using (XmlReader reader = XmlReader.Create(rssUrl))
            {
                var feed = SyndicationFeed.Load(reader);
                var latest = feed.Items.FirstOrDefault();

                if (latest != null)
                {
                    ViewBag.Title = latest.Title.Text;
                    ViewBag.Content = latest.Summary.Text;
                    ViewBag.Date = latest.PublishDate.DateTime.ToString("dd/MM/yyyy");
                }
            }
            return View();
        }

        public ActionResult urlResult(string input)
        {
            string rssUrl = "https://xskt.com.vn/rss-feed/mien-bac-xsmb.rss";

            using (XmlReader reader = XmlReader.Create(rssUrl))
            {
                var feed = SyndicationFeed.Load(reader);
                var latest = feed.Items.FirstOrDefault();

                if (latest != null)
                {
                    ViewBag.Title = latest.Title.Text;
                    ViewBag.Content = latest.Summary.Text;
                    ViewBag.Date = latest.PublishDate.DateTime.ToString("dd/MM/yyyy");
                }
            }
            return View();
        }
        public static string NormalizeMessage(string input)
        {
            // Tách phần số tiền (x...)
            var parts = input.Split('x');
            if (parts.Length != 2) return input; // Không đúng định dạng thì trả về y nguyên

            string numbers = parts[0]; // vd: "545-151-252"
            string bet = "x" + parts[1]; // vd: "x30"

            List<string> results = new List<string>();

            // Nếu có nhiều cụm số ngăn cách bởi "-"
            var groups = numbers.Split('-');

            foreach (var group in groups)
            {
                if (group.Length == 3)
                {
                    // Lấy 2 cặp số liên tiếp
                    results.Add(group.Substring(0, 2) + bet);
                    results.Add(group.Substring(1, 2) + bet);
                }
                else if (group.Length == 2)
                {
                    // Nếu chỉ có 2 số thì giữ nguyên
                    results.Add(group + bet);
                }
            }

            return string.Join(" ", results);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}